"""f451 Labs Logger module."""

__version__ = "0.0.1"
